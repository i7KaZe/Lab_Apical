<?php
$servername = "localhost"; // Votre serveur, généralement localhost
$username = "root"; // Votre nom d'utilisateur pour la base de données
$password = "root"; // Votre mot de passe pour la base de données
$dbname = "local"; // Le nom de votre base de données

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // Définir le mode d'erreur PDO sur exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Erreur de connexion: " . $e->getMessage();
}
?>
