<?php
get_header(); // Ceci inclut votre fichier header.php
?>
    <div class="wrapper">
        <div class="contenuprincipal">
            <hr class="divider">
            <h1 id="titreh1" class="text-center"> Formation PUB020&nbsp;: WordPress, 2023
            </h1>
            <hr class="divider bas">

            <div class="contenu">
                <div id="chapitresformation" data-formation-id="36">
                    <div class="boutonshaut">
                        <div class="float-left">
                        </div>
                        <div class="float-right">
                            <a id="developperreduire" href="#" class="btn btn-secondary" role="button"
                               data-developper="Tout développer" data-reduire="Tout réduire">Tout développer</a>
                        </div>
                        <div class="push"></div>
                    </div>
                    <div id="dragchapitres">


                        <div class="card border-bottom-0" id="dragchapitre_2990">

                            <div class="card-header" id="chapitre-choisir_les_outils_pour_developper_un_site_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-choisir_les_outils_pour_developper_un_site_wordpress">
                                    <span class="titrealigneboutons">1. Choisir les outils pour développer un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-choisir_les_outils_pour_developper_un_site_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2990"
                                     data-id="2990">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2989">

                            <div class="card-header" id="chapitre-travailler_avec_phpstorm_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-travailler_avec_phpstorm_002">
                                    <span class="titrealigneboutons">2. Travailler avec PHPStorm</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-travailler_avec_phpstorm_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2989"
                                     data-id="2989">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2124">

                            <div class="card-header" id="chapitre-travailler_avec_devilbox_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-travailler_avec_devilbox_002">
                                    <span class="titrealigneboutons">3. Travailler avec Devilbox</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-travailler_avec_devilbox_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2124"
                                     data-id="2124">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2147">

                            <div class="card-header" id="chapitre-les_gestionnaires_de_contenus">
                                <a data-toggle="collapse" href="#fichesduchapitre-les_gestionnaires_de_contenus">
                                    <span class="titrealigneboutons">4. Les gestionnaires de contenus</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-les_gestionnaires_de_contenus">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2147"
                                     data-id="2147">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2148">

                            <div class="card-header" id="chapitre-installation_de_wordpress_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-installation_de_wordpress_002">
                                    <span class="titrealigneboutons">5. Installation de WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-installation_de_wordpress_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2148"
                                     data-id="2148">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2149">

                            <div class="card-header"
                                 id="chapitre-amenager_notre_environnement_pour_travailler_efficacement">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-amenager_notre_environnement_pour_travailler_efficacement">
                                    <span class="titrealigneboutons">6. Aménager notre environnement pour travailler efficacement</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-amenager_notre_environnement_pour_travailler_efficacement">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2149"
                                     data-id="2149">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2995">

                            <div class="card-header" id="chapitre-ecrire_un_programme_wordpress_de_qualite_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-ecrire_un_programme_wordpress_de_qualite_002">
                                    <span class="titrealigneboutons">7. Écrire un programme WordPress de qualité</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-ecrire_un_programme_wordpress_de_qualite_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2995"
                                     data-id="2995">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2150">

                            <div class="card-header" id="chapitre-quelques_fonctionnalites_wordpress_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-quelques_fonctionnalites_wordpress_002">
                                    <span class="titrealigneboutons">8. Quelques fonctionnalités WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-quelques_fonctionnalites_wordpress_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2150"
                                     data-id="2150">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2151">

                            <div class="card-header" id="chapitre-le_tableau_de_bord_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_tableau_de_bord_wordpress">
                                    <span class="titrealigneboutons">9. Le tableau de bord WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-le_tableau_de_bord_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2151"
                                     data-id="2151">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2996">

                            <div class="card-header"
                                 id="chapitre-extraits_de_code_tires_des_notes_de_cours_ou_du_web_005">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-extraits_de_code_tires_des_notes_de_cours_ou_du_web_005">
                                    <span class="titrealigneboutons">10. Extraits de code tirés des notes de cours ou du Web</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-extraits_de_code_tires_des_notes_de_cours_ou_du_web_005">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2996"
                                     data-id="2996">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2152">

                            <div class="card-header" id="chapitre-les_themes_themes_et_extensions_plugins_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-les_themes_themes_et_extensions_plugins_wordpress">
                                    <span class="titrealigneboutons">11. Les thèmes (themes) et extensions (plugins) WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-les_themes_themes_et_extensions_plugins_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2152"
                                     data-id="2152">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2918">

                            <div class="card-header" id="chapitre-les_blocs_wordpress_editeur_gutenberg_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-les_blocs_wordpress_editeur_gutenberg_002">
                                    <span class="titrealigneboutons">12. Les blocs WordPress (éditeur Gutenberg)</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-les_blocs_wordpress_editeur_gutenberg_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2918"
                                     data-id="2918">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2998">

                            <div class="card-header" id="chapitre-le_dossier_dev_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_dossier_dev_002">
                                    <span class="titrealigneboutons">13. Le dossier dev</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-le_dossier_dev_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2998"
                                     data-id="2998">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2999">

                            <div class="card-header" id="chapitre-tester_le_site_web_de_facon_structuree_003">
                                14. Tester le site Web de façon structurée (ce chapitre est vide)
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-tester_le_site_web_de_facon_structuree_003">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2999"
                                     data-id="2999">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3000">

                            <div class="card-header" id="chapitre-le_debogueur_de_phpstorm">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_debogueur_de_phpstorm">
                                    <span class="titrealigneboutons">15. Le débogueur de PhpStorm</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-le_debogueur_de_phpstorm">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3000"
                                     data-id="3000">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2322">

                            <div class="card-header" id="chapitre-de_quoi_est_compose_un_theme_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-de_quoi_est_compose_un_theme_wordpress">
                                    <span class="titrealigneboutons">16. De quoi est composé un thème WordPress ?</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-de_quoi_est_compose_un_theme_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2322"
                                     data-id="2322">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2321">

                            <div class="card-header" id="chapitre-le_theme_enfant">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_theme_enfant">
                                    <span class="titrealigneboutons">17. Le thème enfant</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-le_theme_enfant">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2321"
                                     data-id="2321">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2158">

                            <div class="card-header" id="chapitre-securiser_un_site_wordpress_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-securiser_un_site_wordpress_002">
                                    <span class="titrealigneboutons">18. Sécuriser un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-securiser_un_site_wordpress_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2158"
                                     data-id="2158">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2231">

                            <div class="card-header" id="chapitre-mettre_a_jour_wordpress_le_theme_et_les_extensions">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-mettre_a_jour_wordpress_le_theme_et_les_extensions">
                                    <span class="titrealigneboutons">19. Mettre à jour WordPress, le thème et les extensions</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-mettre_a_jour_wordpress_le_theme_et_les_extensions">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2231"
                                     data-id="2231">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2379">

                            <div class="card-header" id="chapitre-localisation_d_un_site_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-localisation_d_un_site_wordpress">
                                    <span class="titrealigneboutons">20. Localisation d&#039;un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-localisation_d_un_site_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2379"
                                     data-id="2379">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2477">

                            <div class="card-header" id="chapitre-internationalisation_d_un_site_wordpress_003">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-internationalisation_d_un_site_wordpress_003">
                                    <span class="titrealigneboutons">21. Internationalisation d&#039;un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-internationalisation_d_un_site_wordpress_003">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2477"
                                     data-id="2477">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2548">

                            <div class="card-header" id="chapitre-mise_en_ligne_d_un_site_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-mise_en_ligne_d_un_site_wordpress">
                                    <span class="titrealigneboutons">22. Mise en ligne d&#039;un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-mise_en_ligne_d_un_site_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2548"
                                     data-id="2548">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3001">

                            <div class="card-header" id="chapitre-referencer_son_site_web_004">
                                <a data-toggle="collapse" href="#fichesduchapitre-referencer_son_site_web_004">
                                    <span class="titrealigneboutons">23. Référencer son site Web</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-referencer_son_site_web_004">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3001"
                                     data-id="3001">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2550">

                            <div class="card-header" id="chapitre-programmation_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-programmation_wordpress">
                                    <span class="titrealigneboutons">24. Programmation WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-programmation_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2550"
                                     data-id="2550">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3002">

                            <div class="card-header" id="chapitre-deboguer_un_site_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-deboguer_un_site_wordpress">
                                    <span class="titrealigneboutons">25. Déboguer un site WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-deboguer_un_site_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3002"
                                     data-id="3002">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2551">

                            <div class="card-header" id="chapitre-hooks_points_d_ancrage">
                                <a data-toggle="collapse" href="#fichesduchapitre-hooks_points_d_ancrage">
                                    <span class="titrealigneboutons">26. Les hooks (points d&#039;ancrage)</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-hooks_points_d_ancrage">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2551"
                                     data-id="2551">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3003">

                            <div class="card-header" id="chapitre-le_favicon_003">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_favicon_003">
                                    <span class="titrealigneboutons">27. Le favicon</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-le_favicon_003">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3003"
                                     data-id="3003">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2552">

                            <div class="card-header" id="chapitre-shortcodes">
                                <a data-toggle="collapse" href="#fichesduchapitre-shortcodes">
                                    <span class="titrealigneboutons">28. Les shortcodes WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-shortcodes">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2552"
                                     data-id="2552">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2553">

                            <div class="card-header"
                                 id="chapitre-feuilles_de_style_et_scripts_pour_les_shortcodes_ou_les_extensions">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-feuilles_de_style_et_scripts_pour_les_shortcodes_ou_les_extensions">
                                    <span class="titrealigneboutons">29. Feuilles de style et scripts pour les shortcodes ou les extensions</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-feuilles_de_style_et_scripts_pour_les_shortcodes_ou_les_extensions">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2553"
                                     data-id="2553">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2554">

                            <div class="card-header" id="chapitre-base_de_donnees_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-base_de_donnees_wordpress">
                                    <span class="titrealigneboutons">30. La base de données WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-base_de_donnees_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2554"
                                     data-id="2554">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2555">

                            <div class="card-header" id="chapitre-donnees_personnalisees_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-donnees_personnalisees_wordpress">
                                    <span class="titrealigneboutons">31. Les données personnalisées WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-donnees_personnalisees_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2555"
                                     data-id="2555">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2919">

                            <div class="card-header" id="chapitre-le_mode_maintenance">
                                <a data-toggle="collapse" href="#fichesduchapitre-le_mode_maintenance">
                                    <span class="titrealigneboutons">32. Le mode maintenance</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-le_mode_maintenance">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2919"
                                     data-id="2919">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2920">

                            <div class="card-header" id="chapitre-l_envoi_de_courriel">
                                <a data-toggle="collapse" href="#fichesduchapitre-l_envoi_de_courriel">
                                    <span class="titrealigneboutons">33. L&#039;envoi de courriel</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-l_envoi_de_courriel">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2920"
                                     data-id="2920">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2921">

                            <div class="card-header"
                                 id="chapitre-traiter_un_formulaire_cote_site_web_dans_wordpress_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-traiter_un_formulaire_cote_site_web_dans_wordpress_002">
                                    <span class="titrealigneboutons">34. Traiter un formulaire côté site Web dans WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-traiter_un_formulaire_cote_site_web_dans_wordpress_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2921"
                                     data-id="2921">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2922">

                            <div class="card-header" id="chapitre-les_messages_dans_le_tableau_de_bord_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-les_messages_dans_le_tableau_de_bord_wordpress">
                                    <span class="titrealigneboutons">35. Les messages dans le tableau de bord WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-les_messages_dans_le_tableau_de_bord_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2922"
                                     data-id="2922">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2923">

                            <div class="card-header"
                                 id="chapitre-ajouter_des_options_de_menu_dans_le_tableau_de_bord_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-ajouter_des_options_de_menu_dans_le_tableau_de_bord_wordpress">
                                    <span class="titrealigneboutons">36. Ajouter des options de menu dans le tableau de bord WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-ajouter_des_options_de_menu_dans_le_tableau_de_bord_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2923"
                                     data-id="2923">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3004">

                            <div class="card-header"
                                 id="chapitre-distinguer_le_site_en_developpement_du_site_en_production">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-distinguer_le_site_en_developpement_du_site_en_production">
                                    <span class="titrealigneboutons">37. Distinguer le site en développement du site en production</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-distinguer_le_site_en_developpement_du_site_en_production">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3004"
                                     data-id="3004">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2465">

                            <div class="card-header" id="chapitre-les_nonces_dans_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-les_nonces_dans_wordpress">
                                    <span class="titrealigneboutons">38. Les nonces dans WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-les_nonces_dans_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2465"
                                     data-id="2465">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2924">

                            <div class="card-header" id="chapitre-operations_crud_dans_wordpress">
                                <a data-toggle="collapse" href="#fichesduchapitre-operations_crud_dans_wordpress">
                                    <span class="titrealigneboutons">39. Opérations CRUD dans WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-operations_crud_dans_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2924"
                                     data-id="2924">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2925">

                            <div class="card-header" id="chapitre-formulaire_d_ajout_dans_le_tableau_de_bord_wordpress">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-formulaire_d_ajout_dans_le_tableau_de_bord_wordpress">
                                    <span class="titrealigneboutons">40. Formulaire d&#039;ajout dans le tableau de bord WordPress</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-formulaire_d_ajout_dans_le_tableau_de_bord_wordpress">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2925"
                                     data-id="2925">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2926">

                            <div class="card-header" id="chapitre-liste_deroulante_dans_un_formulaire">
                                <a data-toggle="collapse" href="#fichesduchapitre-liste_deroulante_dans_un_formulaire">
                                    <span class="titrealigneboutons">41. Liste déroulante dans un formulaire</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-liste_deroulante_dans_un_formulaire">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2926"
                                     data-id="2926">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3005">

                            <div class="card-header" id="chapitre-modifier_des_donnees_personnalisees_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-modifier_des_donnees_personnalisees_002">
                                    <span class="titrealigneboutons">42. Modifier des données personnalisées</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-modifier_des_donnees_personnalisees_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3005"
                                     data-id="3005">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2914">

                            <div class="card-header" id="chapitre-supprimer_des_donnees_personnalisees_002">
                                <a data-toggle="collapse"
                                   href="#fichesduchapitre-supprimer_des_donnees_personnalisees_002">
                                    <span class="titrealigneboutons">43. Supprimer des données personnalisées</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-supprimer_des_donnees_personnalisees_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2914"
                                     data-id="2914">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3006">

                            <div class="card-header" id="chapitre-ajax_003">
                                <a data-toggle="collapse" href="#fichesduchapitre-ajax_003">
                                    <span class="titrealigneboutons">44. AJAX</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-ajax_003">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3006"
                                     data-id="3006">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3007">

                            <div class="card-header" id="chapitre-les_options_d_un_theme_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-les_options_d_un_theme_002">
                                    <span class="titrealigneboutons">45. Les options d&#039;un thème</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-les_options_d_un_theme_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3007"
                                     data-id="3007">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3008">

                            <div class="card-header" id="chapitre-consommer_un_service_web_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-consommer_un_service_web_002">
                                    <span class="titrealigneboutons">46. Consommer un service Web</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-consommer_un_service_web_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3008"
                                     data-id="3008">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_3021">

                            <div class="card-header" id="chapitre-developper_une_extension_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-developper_une_extension_002">
                                    <span class="titrealigneboutons">47. Développer une extension</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-developper_une_extension_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-3021"
                                     data-id="3021">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <h2 class="separation" id="dragchapitre_2994">Chapitres supplémentaires
                            <div class="float-right boutonsalignes">
                            </div>
                        </h2>


                        <div class="card border-bottom-0" id="dragchapitre_2991">

                            <div class="card-header" id="chapitre-travailler_avec_ampps_ou_xampp">
                                <a data-toggle="collapse" href="#fichesduchapitre-travailler_avec_ampps_ou_xampp">
                                    <span class="titrealigneboutons">48. Travailler avec AMPPS ou XAMPP</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-travailler_avec_ampps_ou_xampp">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2991"
                                     data-id="2991">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2982">

                            <div class="card-header" id="chapitre-travailler_avec_vs_code_002">
                                <a data-toggle="collapse" href="#fichesduchapitre-travailler_avec_vs_code_002">
                                    <span class="titrealigneboutons">49. Travailler avec VS Code</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false"
                                 id="fichesduchapitre-travailler_avec_vs_code_002">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2982"
                                     data-id="2982">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>


                        <div class="card border-bottom-0" id="dragchapitre_2997">

                            <div class="card-header" id="chapitre-divers">
                                <a data-toggle="collapse" href="#fichesduchapitre-divers">
                                    <span class="titrealigneboutons">50. Divers</span>
                                </a>
                                <div class="float-right boutonsalignes">
                                </div>

                            </div>
                            <div class="collapse" aria-expanded="false" id="fichesduchapitre-divers">

                                <div class="card-body aucune-marge-haut-bas listefichesajax" id="fichesduchapitre-2997"
                                     data-id="2997">
                                    <span class="encoursdegeneration">Liste en cours de génération...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
get_footer(); // Ceci inclut votre fichier footer.php
?>