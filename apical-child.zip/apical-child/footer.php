<?php
/**
 * Le pied de page pour notre thème.
 * Ceci ferme la balise <div> principale ouverte dans header.php
 * et tout le contenu après.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 */
?>

<footer>
    <div class="container">
        <div class="row">
            <div class="col text-center">© 2023 Tous droits réservés.</div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col text-center">Conception et développement de la plateforme : <span class="auteur"><a
                            href="https://tit-kaze.ca" target="_blank">Nathan Reyes</a></span></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col text-center mt-3">
                <a class="btn btn-primary"
                   href="https://apical.xyz/contact?de=https%3A%2F%2Fapical.xyz%2Ffiches%2Flocalisation_d_un_site_wordpress%2FPage_d_erreur_404">Écrivez-moi&nbsp;!</a>
            </div>
        </div>
    </div>
</footer>
</body>
</html>


